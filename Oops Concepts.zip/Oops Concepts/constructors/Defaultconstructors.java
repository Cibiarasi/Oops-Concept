
class Satudent[
    int roll;
    String name;
    Student(){
        roll=1;
        name="cibi";
        
    }
    void display(){
        System.out.println(roll+" "+name);
    }

]
public class Defaultconstructors{
    public static void main(String[] args){
        Student s=new Student();
        s.display();

        

        

    }
}