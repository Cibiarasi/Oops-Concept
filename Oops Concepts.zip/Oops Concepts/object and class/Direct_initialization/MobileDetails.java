class Mobile{
    String name="Redmi";
    int price=100000;
    void display(){
        System.out.println(name+" "+price+" ");
    }
}


public class MobileDetails{
    public static void main(String[] args){
        Mobile m=new Mobile();
        m.display();

    }
}