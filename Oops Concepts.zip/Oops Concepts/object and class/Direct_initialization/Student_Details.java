//package Direct_initialization.Student_Details;
class Student{
    int roll=12;
    String name="cibi";
    int marks=100;
    void display(){
        System.out.println(roll+" "+" "+name+" "+marks+" ");
    }
}

public class Student_Details {
    public static void main(String[] args){
        Student s=new Student();
        s.display();

    }
    
}
