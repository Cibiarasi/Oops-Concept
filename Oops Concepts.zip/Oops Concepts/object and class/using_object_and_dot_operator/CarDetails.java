//package using_object_and_dot_operator.CarDetails;

class Car{
    int no;
    String brand;
}

public class CarDetails {
    public static void main(String[] args){
        Car c=new Car();
        c.no=121;
        c.brand="toyota";
        System.out.println(c.no+" "+c.brand+" ");

    }
    
}
