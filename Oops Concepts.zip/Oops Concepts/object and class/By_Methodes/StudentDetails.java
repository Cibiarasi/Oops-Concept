//package By_Methodes;


class Student{
    int roll;
    String name;
    double marks;
    void display(int r,String n,double m){
        roll=r;
        name=n;
        marks=m;
    }
    void res(){
        System.out.println(roll+" "+name+" "+marks);
    }
}
public class StudentDetails {
    public static void main(String[] args){
        Student s=new Student();
        s.display(12,"cibi",100.0);
        s.res();

    }
    
}
