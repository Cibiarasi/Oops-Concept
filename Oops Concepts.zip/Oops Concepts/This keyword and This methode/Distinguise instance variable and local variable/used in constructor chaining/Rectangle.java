//package Distinguise instance variable and local variable.used in constructor chaining;


class Shape{
    int len;
    int bre;
    Shape(){
        this(10,20);
    }
    Shape(int len,int bre){
        this.len=len;
        this.bre=bre;
    }
    void display(){
        System.out.println(len+" "+bre);
    }

}
public class Rectangle {
    public static void main(String[] args){
        Shape s=new Shape();
        s.display();
    }
    
}
