//package Distinguise instance variable and local variable.used in constructor chaining;


class Student{
    int id;
    String name;
    Student(){
        this(1,"cibi");
    }
    Student(int id,String name){
        this.id=id;
        this.name=name;
    }
    void display(){
        System.out.println(id+" "+name);
    }
}
public class StudentDetails {
    public static void main(String[] args){
        Student s=new Student();
        s.display();

    }
    
}
