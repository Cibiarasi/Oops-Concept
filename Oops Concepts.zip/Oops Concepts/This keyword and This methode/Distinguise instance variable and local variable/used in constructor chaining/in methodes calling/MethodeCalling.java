//package Distinguise instance variable and local variable.used in constructor chaining.in methodes calling;



class Methode{
    void res(){
        System.out.println("res methode");

    }
    void display(){
        this.res();
        System.out.println("display methode");
    }
}
public class MethodeCalling {
    public static void main(String[] args){
        Methode m=new Methode();
        m.display();

    }
 
    nrkem,flr
}
