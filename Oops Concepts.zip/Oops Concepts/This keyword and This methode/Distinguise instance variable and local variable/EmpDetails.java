class Employee{
    int id;
    String name;
    Employee(int id,String name){
        this.id=id;
        this.name=name;
    }
    void display(){
        System.out.println(id+" "+name);
    }
}


public class EmpDetails{
    public static void main(String[] args){
        Employee e=new Employee(1,"cibi");
        e.display();

    }
}