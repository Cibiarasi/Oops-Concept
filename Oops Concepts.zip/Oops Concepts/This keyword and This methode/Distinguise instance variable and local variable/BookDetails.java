//package Distinguise instance variable and local variable;


class Book{
    int id;
    String name;
    Book(int id,String name){
        this.id=id;
        this.name=name;
    }
    void display(){
        System.out.println(id+" "+name);
    }
}
public class BookDetails {
    public static void main(String[] args){
        Book b=new Book(01,"universe");
        b.display();
    }
    
}
