//..package Public;


class Student{
    public int roll;
    public String name;
    void res(int roll,String name){
        this.roll=roll;
        this.name=name;
        
    }
       
    

}
public class Studnetdetails {
    public static void main(String[] args){
        Student s=new Student();
        s.res(10,"cibi");
        System.out.println(s.name)
    
    }
    
}
