
class StuAge{
    private int age;
    public void setAge(int age){
        this.age=age;
    }
    public int getAge(){
        return age;
    }

}

public class Student{
    public static void main(String[] args){
        StuAge s=new StuAge();
        s.setAge(20);
        System.out.println(s.getAge());
    }
}