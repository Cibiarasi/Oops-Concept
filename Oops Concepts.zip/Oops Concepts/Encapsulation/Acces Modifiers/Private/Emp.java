
class details{
    public String name;
    private double salary;
    public void setAge(double salary,String name){
        this.name=name;
        this.salary=salary;
    }
    public double getAge(){
        return salary;
    }
    
    
}

public class Emp{
    public static void main(String[]args){
        details s=new details();
        s.setAge(1000.000,"cibi");
        System.out.println(s.getAge());
        System.out.println(s.name);
     


    }
}